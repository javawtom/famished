# Design System Strategy: The Serene Sanctuary

## 1. Overview & Creative North Star
**Creative North Star: The Gentle Editorial**
This design system rejects the frantic, high-density patterns of traditional productivity apps. Instead, it adopts a high-end editorial aesthetic—reminiscent of a premium wellness journal or a boutique gallery guide. We prioritize "The Breathable Interface." 

To break the "template" look, we move away from centered, rigid grids. We embrace **intentional asymmetry**: large headers may be offset, and white space is used as a functional element to guide the eye rather than just a gap between content. By using a sophisticated typography scale and tonal layering, we create a sense of quiet authority and unwavering support for users navigating low-energy days.

---

## 2. Colors & Surface Philosophy
The palette is rooted in nature and warmth, designed to lower cortisol levels and reduce cognitive load.

### The "No-Line" Rule
**Strict Mandate:** Traditional 1px solid borders are prohibited for sectioning or containment. 
Boundaries must be defined through:
*   **Background Shifts:** Place a `surface_container_low` card on a `surface` background.
*   **Tonal Transitions:** Use `surface_container` to subtly distinguish a header from the body without a harsh horizontal rule.

### Surface Hierarchy & Nesting
Think of the UI as layers of fine, heavy-weight paper.
*   **Base:** `surface` (#faf9f5) serves as the canvas.
*   **Tertiary Sections:** Use `surface_container_low` (#f3f4ef) for secondary information groups.
*   **Active Focus:** Use `surface_container_highest` (#e0e4dd) for high-priority interactive elements.

### The "Glass & Gradient" Rule
To add soul to the "flat" palette, use subtle gradients for primary actions. A transition from `primary` (#4f645b) to `primary_dim` (#43574f) creates a soft, tactile depth. For floating navigation or modals, use **Glassmorphism**: apply `surface_container_lowest` at 80% opacity with a `24px` backdrop blur to allow the soft sage tones to bleed through the edges.

---

## 3. Typography
We use **Manrope**, a modern geometric sans-serif that balances functional legibility with a soft, humanistic touch.

*   **Display (lg/md/sm):** Used for daily encouragement and morning headers. These are the "voice" of the app—calm, large, and confident.
*   **Headline & Title:** Use `Bold` weights for key instructions (e.g., "Eat a small meal"). This provides a clear anchor for users who may be experiencing "brain fog."
*   **Body (lg/md):** Set with generous line-height (1.6) to ensure the text never feels cramped.
*   **Label (md/sm):** Reserved for metadata, using the `secondary` (#5f5f5c) color to keep the visual hierarchy quiet.

---

## 4. Elevation & Depth
Depth in this system is a whisper, not a shout. We achieve hierarchy through **Tonal Layering** rather than shadows.

*   **The Layering Principle:** A `surface_container_lowest` (#ffffff) card sitting on a `surface_container` (#edefe9) background provides all the "lift" required. 
*   **Ambient Shadows:** If a floating element (like a FAB) is necessary, use a "Botanical Shadow": a 20% opacity of `on_surface` with a `32px` blur and a `12px` Y-offset. It should feel like a soft shadow cast by morning light.
*   **The "Ghost Border" Fallback:** If accessibility requires a stroke (e.g., in high-contrast mode), use `outline_variant` (#afb3ad) at **15% opacity**. Never use 100% opacity for borders.

---

## 5. Components

### Cards & Lists
*   **Rule:** Forbid divider lines. 
*   **Implementation:** Use `Spacing 6` (2rem) to separate list items. For routine tasks, use a `surface_container_low` background that shifts to `primary_container` when a task is marked "complete." This provides a "blossoming" visual cue of progress.

### Buttons
*   **Primary:** High-pill shape (`rounded-full`). Background: Gradient of `primary` to `primary_dim`. Text: `on_primary`. 
*   **Secondary:** `surface_container_high` background with `on_surface` text. No border.
*   **Tertiary:** Text-only using `primary` color in `title-sm` bold.

### Progress Cues (Signature Component)
*   **The Soft Fill:** Instead of a thin loading bar, use a wide, soft-edged track (`rounded-xl`). The progress fill should be a gentle pulse of `primary_fixed_dim`. Completion is signaled by the background color of the entire section shifting to a warm `primary_container`, giving a physical sense of "filling the room" with success.

### Input Fields
*   **Style:** Minimalist. A soft `surface_container` block with `rounded-md`. The label should always be visible in `label-md` to reduce memory strain. Error states use `error` (#a73b21) only in the text and a subtle 2px left-accent bar, avoiding scary red boxes.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical margins (e.g., more whitespace on the left than the right) to create an editorial, premium feel.
*   **Do** use `Spacing 16` and `20` to separate major sections. Let the app breathe.
*   **Do** prioritize icons that are "Open Path" (thin lines, non-filled) to keep the UI light.

### Don't
*   **Don't** use pure black (#000000). Use `on_surface` (#2f332f) for all "black" text to maintain a soft visual frequency.
*   **Don't** use "Pop-up" animations. Use "Fade and Slide" (upward 20px) over 400ms to mimic a gentle rising motion.
*   **Don't** use more than 3 icons on a single screen. Rely on typography and color blocks to convey meaning.